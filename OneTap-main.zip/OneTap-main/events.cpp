#include "events.h"

c_event_manager event_manager;

void c_event_manager::player_hurt( IGameEvent* _event )
{

}

void c_event_manager::player_death(IGameEvent* _event)
{

}

void c_event_manager::player_disconnect( IGameEvent* _event )
{

}

void c_event_manager::player_footstep( IGameEvent* _event )
{

}

void c_event_manager::item_purchase( IGameEvent* _event )
{

}

void c_event_manager::bullet_impact( IGameEvent* _event )
{

}

void c_event_manager::weapon_fire( IGameEvent* _event )
{

}

void c_event_manager::round_prestart( IGameEvent* _event )
{

}

void c_event_manager::round_start( IGameEvent* _event )
{

}

void c_event_manager::round_freeze_end( IGameEvent* _event )
{

}