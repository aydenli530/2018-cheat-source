#pragma once

#pragma warning( disable : 4100) //unreferenced formal parameter
#pragma warning( disable : 4101) //unreferenced local variable
#pragma warning( disable : 4189) //local variable is initialized but not referenced
#pragma warning( disable : 4389) //signed/unsigned mismatch

#include <SDKDDKVer.h>

#include "sdk.h"
#include "fnv.h"
#include "string.h"
#include "util.h"